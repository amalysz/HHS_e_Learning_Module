﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace HHS_e_Learning_Module.Controllers
{
    [Authorize]
    public class LTSController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Queue()
        {
            return View();
        }
        public IActionResult ViewPendingRequests()
        {
            return View();
        }

        public IActionResult Catalog()
        {
            return View();
        }
    }
}