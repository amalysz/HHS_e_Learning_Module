﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace HHS_e_Learning_Module.Controllers
{
    [Authorize(Roles = "SME")]
    public class SMEController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult RequestNewModule()
        {
            return View();
        }

        public IActionResult ViewPendingRequests()
        {
            return View();
        }

        public IActionResult FAQ()
        {
            return View();
        }
    }
}
