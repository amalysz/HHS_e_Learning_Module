using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HHS_e_Learning_Module_Platform.Views.Home
{
    public class LTS_QueueModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
